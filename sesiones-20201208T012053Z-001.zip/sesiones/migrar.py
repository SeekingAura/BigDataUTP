from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy import Column, Integer, String, Float, Text, Boolean, ForeignKey
import json

motor = create_engine('mysql+pymysql://admin:bigdata20@localhost:3306/sqlejemplo')
Session = sessionmaker(bind=motor)
session = Session()
Base = declarative_base()

class Departamento(Base):
    __tablename__='departamentos'
    id=Column(Integer, primary_key=True)
    nombre=Column(Text)

class Municipio(Base):
    __tablename__='municipios'
    id=Column(Integer, primary_key=True)
    nombre=Column(Text)
    id_d = Column(Integer, ForeignKey('departamentos.id'))

def Ad_Dptos(nom_archivo):
    with open(nom_archivo) as archivo:
        saltar=True
        for linea in archivo:
            if saltar:
                saltar=False
            else:
                cad=linea.strip()
                print cad
                dp = Departamento(nombre=cad)
                session.add(dp)
                session.commit()
                print(dp.id, dp.nombre)

def Ad_Municipios(nom_archivo):
    with open(nom_archivo) as archivo:
        for linea in archivo:
            cad=linea.strip()
            obj = json.loads(cad)
            id_d= Ret_IdDpto(obj['_id'])
            print (id_d,obj['_id'], type(obj))
            ls_municipios=obj['municipios']
            dc_mun=[]
            for m in ls_municipios:
                if m not in dc_mun:
                    dc.append(m)
                #print m
            print (dc_mun)
            for mun_i in dc_mun:
                mun = Municipio(nombre=mun_i, id_d=id_d)
                session.add(mun)
                session.commit()

def Ret_IdDpto(nom):
    info=session.query(Departamento).filter_by(nombre=nom).first()
    print info.id, info.nombre
    return info.id

if __name__ == '__main__':
    Base.metadata.create_all(motor)
    #Ad_Dptos('Departamentos.csv')
    Ad_Municipios('Municipios.json')
    Ret_IdDpto('RISARALDA')
