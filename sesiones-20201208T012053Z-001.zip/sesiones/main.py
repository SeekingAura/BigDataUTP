import db
from modelos import *

def Insertar():
        pass

if __name__=='__main__':
        db.Base.metadata.create_all(db.motor)
        Insertar()

