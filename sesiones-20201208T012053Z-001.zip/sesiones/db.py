from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

motor = create_engine('mysql+pymysql://admin:bigdata20@localhost:3306/sqlejemplo')
Session = sessionmaker(bind=motor)
session = Session()
Base = declarative_base()

